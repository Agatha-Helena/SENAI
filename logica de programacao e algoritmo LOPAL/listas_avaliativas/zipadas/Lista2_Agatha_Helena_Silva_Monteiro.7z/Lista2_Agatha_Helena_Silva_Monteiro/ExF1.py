# -*- coding: UTF-8 -*-

print("""Olá, eu irei lhe mostrar uma sequência de números de 1 a 50 e depois o inverso (de 50 a 1)!
""")

for v in range(1, 51):
     print (v)


print("""
Agora ao contrário!!!!!!
""")
for v in range(50, 0, -1):
    print (v)

print("""
Legal, né? :P""")
